'use strict';

const fs   = require('fs-extra');
const path = require('path');
const { fetchYouTubeTrends } = require('./youtubeAnalyzer');

// ─────────────────────────────────────────────
// lessons_learned.json 로드
// ─────────────────────────────────────────────
const LESSONS_PATH = path.join(__dirname, 'memory', 'lessons_learned.json');

function loadLessons() {
    try {
        if (fs.existsSync(LESSONS_PATH)) {
            return JSON.parse(fs.readFileSync(LESSONS_PATH, 'utf8'));
        }
    } catch (e) {
        console.error('[OZ Error] Failed to read lessons_learned.json', e);
    }
    return {
        successful_genres:    [],
        technical_issues:     [],
        external_trends:      [],
        performance_history:  [],
        last_youtube_trends:  null,
        last_analyzed:        null
    };
}

let lessons_learned = loadLessons();

// ─────────────────────────────────────────────
// PromptEngineer 클래스
// ─────────────────────────────────────────────
class PromptEngineer {

    constructor() {
        this.reload();
        this._initData();
    }

    // ── 데이터 초기화 ──────────────────────────
    _initData() {

        this.trends = {
            genres:      ["Lofi Jazz House", "Organic Ambient", "Classical Performance", "Euro Synthwave", "Afro House"],
            moods:       ["Cozy", "Healing", "Elegant", "Viral", "Hypnotic"],
            instruments: ["Grand Piano", "Soft Strings", "Vintage Synths", "Nature Sounds", "Sub Bass"],
            vocals:      ["Instrumental Only", "Ambient Whispers", "Ethereal Hum"],
            themes: [
                "OZ CAFE", "Nature/ASMR Sanctuary", "Classical Performance",
                "Euro Synth Night", "Midnight Solstice Afro", "Spring Blossom Walk",
                "Lofi Study Room", "Tokyo City Pop", "Midnight Chill",
                "Cinematic Orchestral", "Seoul Rainy Day", "Aura Brazilian Bounce",
                "Cozy Acoustic Evening", "Deep Sleep Therapy", "Neo Soul Groove",
                "Funk Groove Session", "Berlin Minimal", "Winter Christmas Jazz",
                "Autumn Nostalgic Walk"
            ]
        };

        // ── 기본 weight 테이블 (baseScore) ──────
        this.baseWeightTable = [
            { theme: "OZ CAFE",                genreMatch: "Jazz",        baseScore: 60 },
            { theme: "Lofi Study Room",        genreMatch: "Lofi",        baseScore: 65 },
            { theme: "Nature/ASMR Sanctuary",  genreMatch: "Ambient",     baseScore: 55 },
            { theme: "Classical Performance",  genreMatch: "Classical",   baseScore: 52 },
            { theme: "Tokyo City Pop",         genreMatch: "City Pop",    baseScore: 58 },
            { theme: "Cinematic Orchestral",   genreMatch: "Cinematic",   baseScore: 55 },
            { theme: "Euro Synth Night",       genreMatch: "Synthwave",   baseScore: 50 },
            { theme: "Spring Blossom Walk",    genreMatch: "Acoustic",    baseScore: 45 },
            { theme: "Midnight Chill",         genreMatch: "Downtempo",   baseScore: 50 },
            { theme: "Seoul Rainy Day",        genreMatch: "K-Indie",     baseScore: 50 },
            { theme: "Neo Soul Groove",        genreMatch: "Neo Soul",    baseScore: 48 },
            { theme: "Midnight Solstice Afro", genreMatch: "Afro House",  baseScore: 40 },
            { theme: "Aura Brazilian Bounce",  genreMatch: "Phonk",       baseScore: 40 },
            { theme: "Cozy Acoustic Evening",  genreMatch: "Folk",        baseScore: 44 },
            { theme: "Deep Sleep Therapy",     genreMatch: "Sleep",       baseScore: 50 },
            { theme: "Funk Groove Session",    genreMatch: "Funk",        baseScore: 42 },
            { theme: "Berlin Minimal",         genreMatch: "Minimal",     baseScore: 38 },
            { theme: "Winter Christmas Jazz",  genreMatch: "Christmas",   baseScore: 35 },
            { theme: "Autumn Nostalgic Walk",  genreMatch: "Autumn",      baseScore: 42 }
        ];

        // ── 레퍼런스 아티스트 (프롬프트 내부 전용 — 외부 노출 금지) ──
        this.referenceArtists = {
            "OZ CAFE":                { internal: ["Miles Davis", "Bill Evans", "Chet Baker"] },
            "Nature/ASMR Sanctuary":  { internal: ["Brian Eno", "Harold Budd"] },
            "Classical Performance":  { internal: ["Yiruma", "Ludovico Einaudi", "Max Richter"] },
            "Euro Synth Night":       { internal: ["Kavinsky", "Perturbator", "FM-84"] },
            "Spring Blossom Walk":    { internal: ["Jack Johnson", "Ben Harper"] },
            "Lofi Study Room":        { internal: ["Nujabes", "J Dilla", "Idealism"] },
            "Tokyo City Pop":         { internal: ["Tatsuro Yamashita", "Mariya Takeuchi", "Anri"] },
            "Midnight Chill":         { internal: ["Bonobo", "Tycho", "Thievery Corporation"] },
            "Cinematic Orchestral":   { internal: ["Hans Zimmer", "Ennio Morricone"] },
            "Seoul Rainy Day":        { internal: ["Standing Egg", "Hyukoh", "10cm"] },
            "Neo Soul Groove":        { internal: ["D'Angelo", "Erykah Badu", "Hiatus Kaiyote"] },
            "Midnight Solstice Afro": { internal: ["Black Coffee", "Themba", "Enoo Napa"] },
            "Aura Brazilian Bounce":  { internal: ["Anitta", "Tropkillaz"] },
            "Cozy Acoustic Evening":  { internal: ["Nick Drake", "José González"] },
            "Deep Sleep Therapy":     { internal: ["Marconi Union", "Steven Halpern"] },
            "Funk Groove Session":    { internal: ["Herbie Hancock", "Chick Corea"] },
            "Berlin Minimal":         { internal: ["Aphex Twin", "Burial", "Four Tet"] },
            "Winter Christmas Jazz":  { internal: ["Vince Guaraldi", "Frank Sinatra"] },
            "Autumn Nostalgic Walk":  { internal: ["Norah Jones", "Paolo Nutini"] }
        };

        // ── 음악 이론 정보 (BPM / Key / Feel) ──
        this.musicTheory = {
            "OZ CAFE":                { bpm: "72-88",   key: "F major / Bb major", timeSignature: "4/4", feel: "Laid-back swing" },
            "Lofi Study Room":        { bpm: "75-90",   key: "C minor / Eb major", timeSignature: "4/4", feel: "Dusty boom-bap" },
            "Nature/ASMR Sanctuary":  { bpm: "60-70",   key: "Any modal",          timeSignature: "Free", feel: "Breathlike ebb" },
            "Classical Performance":  { bpm: "60-80",   key: "C minor / E minor",  timeSignature: "3/4 or 4/4", feel: "Rubato" },
            "Tokyo City Pop":         { bpm: "100-118", key: "F# major / A major", timeSignature: "4/4", feel: "Groovy disco-funk" },
            "Euro Synth Night":       { bpm: "120-128", key: "D minor",            timeSignature: "4/4", feel: "Driving pulse" },
            "Spring Blossom Walk":    { bpm: "90-104",  key: "G major",            timeSignature: "4/4", feel: "Light strum" },
            "Midnight Chill":         { bpm: "85-100",  key: "Bb minor",           timeSignature: "4/4", feel: "Deep headnod" },
            "Seoul Rainy Day":        { bpm: "76-88",   key: "D major / B minor",  timeSignature: "4/4", feel: "Emotional folk strum" },
            "Cinematic Orchestral":   { bpm: "60-90",   key: "D minor / F major",  timeSignature: "4/4", feel: "Sweeping cinematic" },
            "Neo Soul Groove":        { bpm: "88-98",   key: "Eb major",           timeSignature: "4/4", feel: "Soulful laidback" },
            "Midnight Solstice Afro": { bpm: "122-128", key: "A minor",            timeSignature: "4/4", feel: "Hypnotic tribal loop" },
            "Aura Brazilian Bounce":  { bpm: "130-140", key: "F minor",            timeSignature: "4/4", feel: "Aggressive phonk drop" },
            "Cozy Acoustic Evening":  { bpm: "70-85",   key: "C major / G major",  timeSignature: "4/4", feel: "Fingerpicked warm" },
            "Deep Sleep Therapy":     { bpm: "50-65",   key: "Any",                timeSignature: "Free", feel: "Delta-wave drift" },
            "Funk Groove Session":    { bpm: "100-115", key: "E minor / G major",  timeSignature: "4/4", feel: "Snappy pocket groove" },
            "Berlin Minimal":         { bpm: "128-132", key: "Atonal",             timeSignature: "4/4", feel: "Cold mechanical pulse" },
            "Winter Christmas Jazz":  { bpm: "80-95",   key: "G major / C major",  timeSignature: "4/4", feel: "Warm festive swing" },
            "Autumn Nostalgic Walk":  { bpm: "78-92",   key: "A major / F# minor", timeSignature: "4/4", feel: "Melancholic warmth" }
        };

        // ── 곡 구조 ──────────────────────────────
        this.songStructure = {
            longMix:   "Intro (soft, 30s) → Groove builds → Peak energy (mid) → Cool down → Outro (fade 30s)",
            shortTrack:"Intro → Verse → Chorus → Bridge → Outro",
            ambient:   "Seamless loop-friendly, no hard transitions, evolving textures"
        };

        // ── 썸네일 컨셉 ──────────────────────────
        this.thumbnailConcepts = {
            "OZ CAFE":                { style: "Cinematic warm amber cafe bokeh", text: "COZY JAZZ • STUDY & RELAX",     colorPalette: ["#2C1A0E", "#D4A55A", "#F5ECD7"] },
            "Lofi Study Room":        { style: "Anime girl at desk with rain window", text: "LOFI HIP HOP • STUDY BEATS", colorPalette: ["#1A1A2E", "#E94560", "#F5A623"] },
            "Nature/ASMR Sanctuary":  { style: "Misty forest with soft light rays", text: "HEALING ASMR • NATURE SOUNDS", colorPalette: ["#1B4332", "#52B788", "#D8F3DC"] },
            "Classical Performance":  { style: "Grand piano in candlelit hall",     text: "CLASSICAL PIANO • FOCUS",      colorPalette: ["#1A1A1A", "#C9A84C", "#F0EAD6"] },
            "Tokyo City Pop":         { style: "80s anime Tokyo neon street at night", text: "CITY POP TOKYO • NIGHT DRIVE", colorPalette: ["#0D0221", "#FF6B9D", "#FFE66D"] },
            "Euro Synth Night":       { style: "Neon cyberpunk rain-wet streets",   text: "NIGHT DRIVE • SYNTHWAVE",      colorPalette: ["#0D0D1A", "#FF2D78", "#00F0FF"] },
            "Spring Blossom Walk":    { style: "Cherry blossom path soft sunlight", text: "SPRING WALK • ACOUSTIC FOLK",  colorPalette: ["#FFF0F5", "#FFB7C5", "#8DB48E"] },
            "Cinematic Orchestral":   { style: "Epic mountain vista dramatic clouds", text: "EPIC CINEMATIC • ORCHESTRA",  colorPalette: ["#0A0A0A", "#8B0000", "#D4AF37"] },
            "Seoul Rainy Day":        { style: "Korean cafe window rain bokeh",     text: "RAINY DAY • KOREAN INDIE",    colorPalette: ["#2D2D2D", "#5B8DB8", "#E8E8E8"] },
            "Midnight Chill":         { style: "Dark lounge neon blue haze",        text: "MIDNIGHT CHILL • DOWNTEMPO",  colorPalette: ["#0A0A1A", "#1E3A5F", "#00D4FF"] },
            "Midnight Solstice Afro": { style: "African tribal fire night sky",     text: "AFRO HOUSE • MIDNIGHT",       colorPalette: ["#1A0A00", "#FF6B00", "#FFD700"] }
        };

        // ── 가사 템플릿 ──────────────────────────
        this.lyricTemplates = {
            "OZ CAFE": "(Verse 1)\nSteam rises from the porcelain cup\nRaindrops racing, never giving up\nCozy corner, world is far away\nIn this cafe, I think I'll stay\n\n(Chorus)\nJust the jazz and me tonight\nSoft piano makes it right\nTime slows down in amber light\nEverything feels alright",
            "Nature/ASMR Sanctuary": "Instrumental. (Focus on organic textures, wind, soft water flows, and forest ambiance)",
            "Classical Performance":  "Instrumental. (Elegant and emotional classical performance. No lyrics needed.)",
            "Euro Synth Night": "(Verse 1)\nNeon pulse under the European sky\nAnalog dreams as the city lights fly\nVelocity rising through the electric night\nSynthwave horizon, chasing the light",
            "Spring Blossom Walk": "(Verse 1)\nPink petals falling softly on my skin\nWarm breeze blowing, let the walk begin\nAcoustic melodies, a harmonica's tune\nUnder the dazzling sky of a spring afternoon\n\n(Chorus)\nHolding hands beneath the cherry blossom tree\nWalking at our pace, just you and me\nA spring-time melody drifting on the air\nA piece of this moment, a love we share",
            "Midnight Solstice Afro": "(Verse 1)\nUnder the moon, the rhythm breathes\nAncestral echoes through the leaves\nThe dancefloor calls, the spirits rise\nAfrican soul beneath the skies",
            "Lofi Study Room": "Instrumental. (Dusty vinyl warmth, lo-fi textures, focus-friendly loop)",
            "Tokyo City Pop": "(Verse 1)\nCruising down the neon boulevard\nCity lights reflecting every star\nYou and I in a summer groove\nNothing left to prove",
            "Seoul Rainy Day": "(Verse 1)\n빗소리가 창문을 두드리고\n따뜻한 커피 한 잔 앞에 앉아\n너를 생각하는 이 시간이\n그렇게 아프지는 않아",
            "Autumn Nostalgic Walk": "(Verse 1)\nLeaves of amber line the empty street\nA familiar song beneath my feet\nThe season changing, memory calls\nSomewhere between the rise and falls"
        };

        // ── Shorts 훅 ────────────────────────────
        this.shortsHooks = {
            "OZ CAFE":                ["This coffee shop vibe will change your focus ☕", "The perfect jazz backdrop for deep work", "Ever felt like you're in a 1960s film? Now you can."],
            "Lofi Study Room":        ["This lofi beat will help you focus in 10 seconds 🎧", "Study smarter with the perfect lo-fi groove", "Turn on, tune in, lock in. 📚"],
            "Nature/ASMR Sanctuary":  ["Instantly calm your mind with healing sounds 🌿", "The ultimate sanctuary for a stressful day", "Close your eyes. Let nature take over."],
            "Classical Performance":  ["Feel raw emotion from a grand orchestra 🎹", "Timeless elegance for your quiet moments", "This masterpiece will touch your soul"],
            "Euro Synth Night":       ["Elevate your night drive with this synthwave pulse 🏎️", "Cyberpunk energy for late-night coding", "The beat that keeps the city alive"],
            "Midnight Solstice Afro": ["Get lost in the hypnotic pulse of Afro House 🌙", "Rhythmic healing for the midnight hours", "Connect with the tribal spirit"],
            "Spring Blossom Walk":    ["A beautiful walk under cherry blossoms 🌸", "Sweet male vocal for your spring afternoon", "The perfect spring BGM for couples 🎸"],
            "Tokyo City Pop":         ["80s Tokyo never sounded this good 🌆", "City pop is taking over YouTube again 🇯🇵", "Your aesthetic Japanese summer playlist"],
            "Seoul Rainy Day":        ["Korean indie + rainy day = perfect mood 🌧️", "This song sounds like a Korean film scene", "감성 충전 완료 🎶"],
            "Cinematic Orchestral":   ["This orchestral piece gives you chills 🎻", "The music your movie marathon deserves", "Instant epic mood in 5 seconds"],
            "Deep Sleep Therapy":     ["Fall asleep in under 10 minutes 😴", "The sleep music that actually works", "Your brain needs this tonight 🌙"]
        };

        // ── 트랙 서브 타이틀 DB ──────────────────
        this.trackSubTitles = {
            "OZ CAFE":                ["Midnight Espresso", "Velvet Piano Soul", "Rainy Window Rhythms", "The Hidden Booth", "Soulful Steam", "Vintage Vinyl Breeze", "Quiet Corner Reflections", "Smooth Roast Bebop", "Bossa in the Brewery", "The Last Passenger"],
            "Lofi Study Room":        ["Dusty Pages", "Bedroom at 2AM", "Pencil & Rain", "The Focus Zone", "Lo-fi Daydream", "Cassette Warmth", "Faded Memories", "Study Lamp Glow", "Analog Soul", "Coffee & Code"],
            "Nature/ASMR Sanctuary":  ["Ethereal Forest Mist", "Zen Garden Whispers", "Flowing Crystal Stream", "Deep Earth Resonance", "Cradle of Silence", "Starlight Canopy", "Ancient Tree Breathing", "Celestial Dewdrops", "Sacred Mountain Calm", "The Inner Sanctuary"],
            "Classical Performance":  ["Whispers of the Grand Hall", "Midnight Symphony", "The Ocean's Serenade", "Eternal Echoes", "Starlight Sonata", "Majestic Horizon", "Timeless Waltz", "Celestial Performance", "Gilded Memory", "Sorrow and Grace"],
            "Euro Synth Night":       ["Cyber City Pulse", "Neon Drive 2049", "Velocity Dream", "Analog Horizon", "Synthwave Sky", "Infinite Circuit", "Digital Sunset", "Electric Nostalgia", "Grid Runner", "The Last Signal"],
            "Tokyo City Pop":         ["Shibuya Crossing Dreams", "Summer in Shimokitazawa", "Neon Blossom Avenue", "Late Night Yamanote", "Harajuku Sunset", "Shinjuku After Rain", "Tokyo 1983", "City Lights Reflection", "Electric Youth", "Sunday Groove in Roppongi"],
            "Midnight Chill":         ["Floating at 3AM", "Blue Hour Drift", "Slow City Haze", "Neon Fog", "The Long Way Home", "Sleepless in Motion", "Underwater Calm", "Glitch in the Dark", "Hollow Streets", "Before the Sun"],
            "Cinematic Orchestral":   ["The Last Frontier", "Before the Storm", "Echoes of Eternity", "Rise of the Brave", "Tears of Orion", "The Wanderer's Oath", "Silent Colossus", "Wings of Destiny", "Beyond the Horizon", "Crimson Overture"],
            "Seoul Rainy Day":        ["창문 밖의 빗소리", "혼자인 밤", "따뜻한 아메리카노", "가을 골목길", "네가 떠난 자리", "빗속의 카페", "익숙한 슬픔", "그리움의 온도", "기억의 잔향", "우산 없는 날"],
            "Spring Blossom Walk":    ["Petals in the Wind", "Sunny Afternoon Path", "The First Bloom", "Morning Breeze Melody", "Love in the Air", "Cherish This Moment", "Garden of Dreams", "Spring Harmony", "Walking on Sunshine", "The Sweetest Bloom"],
            "Midnight Solstice Afro": ["Tribal Heartbeat", "Lunar Pulse", "Sahara Night Breeze", "Solstice Rhythm", "Nomadic Echoes", "Dusk to Dawn", "Ancestral Flow", "Rhythmic Trance", "Spirit of the Sands", "Obsidian Moon"],
            "Autumn Nostalgic Walk":  ["Amber Streets", "The Fallen Leaf", "October Letter", "Harvest Moon Walk", "End of September", "Last Warm Day", "Wooden Floors & Tea", "Foggy Morning Trail", "Goodbye Summer", "Between the Seasons"]
        };

        // ── 바이럴 타이틀 템플릿 ──────────────────
        this.viralTitleTemplates = [
            "THIS {Genre} will {Benefit} 🌿 | {Theme}",
            "{Situation} Music for {Target} | {Theme} {Genre} Mix",
            "Better than Coffee: {Mood} {Genre} to {Benefit}",
            "Immersive {Theme} Experience | {Genre} | 1 Hour Mix",
            "Relax your mind with {Theme} | {Genre} {Benefit}",
            "The Ultimate {Genre} for {Situation} | {Theme} Mix",
            "Stop Stress with this {Mood} {Genre} 🎧",
            "Late Night {Theme} | {Genre} for Deep {Situation}"
        ];
    }

    // ── lessons_learned 리로드 ──────────────────
    reload() {
        lessons_learned = loadLessons();
    }

    // ── lessons_learned 저장 ───────────────────
    saveLessons(newData) {
        try {
            const merged = { ...lessons_learned, ...newData, last_updated: new Date().toISOString() };
            fs.ensureDirSync(path.dirname(LESSONS_PATH));
            fs.writeFileSync(LESSONS_PATH, JSON.stringify(merged, null, 2));
            lessons_learned = merged;
            console.log('💾 [Memory] lessons_learned.json 저장 완료');
        } catch (e) {
            console.error('[OZ Error] Failed to save lessons_learned.json', e);
        }
    }

    // ── 채널 성과 기록 ─────────────────────────
    recordSuccess(theme, genre, viewCount) {
        const history = lessons_learned.performance_history || [];
        history.push({ theme, genre, viewCount, date: new Date().toISOString() });

        // successful_genres 갱신 (조회수 1000 이상만)
        const successfulGenres = lessons_learned.successful_genres || [];
        if (viewCount >= 1000 && !successfulGenres.includes(genre)) {
            successfulGenres.push(genre);
        }

        this.saveLessons({ performance_history: history, successful_genres: successfulGenres });
        console.log(`📈 [Record] ${theme} / ${genre} → ${viewCount} views 기록 완료`);
    }

    // ── YouTube 트렌드 캐시 관리 (7일 주기) ────
    async fetchYouTubeTrendsWithCache() {
        const cache       = lessons_learned.last_youtube_trends;
        const lastAnalyzed = lessons_learned.last_analyzed;

        if (cache && lastAnalyzed) {
            const daysSince = (Date.now() - new Date(lastAnalyzed)) / (1000 * 60 * 60 * 24);
            if (daysSince < 7) {
                console.log(`\n📦 [Cache Hit] YouTube 트렌드 캐시 사용 (${daysSince.toFixed(1)}일 전 데이터)`);
                return cache;
            }
        }

        console.log('\n🔄 [Cache Miss] 7일 경과 → YouTube 실시간 재분석 시작');
        const fresh = await fetchYouTubeTrends();
        this.saveLessons({ last_youtube_trends: fresh, last_analyzed: new Date().toISOString() });
        return fresh;
    }

    // ── 최적 테마 선택 (메인 전략 엔진) ────────
    async selectOptimalTheme(rank = 0) {
        console.log('\n╔══════════════════════════════════════════╗');
        console.log('║   OZ Strategy Engine — Theme Selector    ║');
        console.log('╚══════════════════════════════════════════╝');

        // ① YouTube 트렌드 score (캐시 우선)
        const youtubeTrends = await this.fetchYouTubeTrendsWithCache();

        // ② baseScore + YouTube score 합산
        let weightTable = this.baseWeightTable.map(item => {
            const ytScore   = youtubeTrends?.[item.theme] || 0;
            const finalScore = item.baseScore + ytScore;
            console.log(`  📊 ${item.theme.padEnd(26)}: base(${String(item.baseScore).padStart(2)}) + yt(${String(ytScore).padStart(3)}) = ${finalScore}`);
            return { ...item, score: finalScore };
        });

        // ③ 70:20:10 전략 모드
        const rand = Math.random();
        let mode;

        if (rand < 0.1) {
            // 🎲 탐색 (10%)
            mode = 'Exploration';
            weightTable = weightTable.map(item => ({ ...item, score: Math.random() * 100 }));
            console.log('\n📡 [Exploration] 10% — 완전 랜덤 탐색 모드');

        } else if (rand < 0.3) {
            // 📡 시장 정렬 (20%)
            mode = 'Market Alignment';
            console.log('\n📡 [Market Alignment] 20% — lessons_learned external_trends 반영');
            const extTrends = lessons_learned.external_trends || [];
            if (extTrends.length > 0) {
                weightTable = weightTable.map(item => {
                    const matchCount = extTrends.filter(t =>
                        t.found_title?.toLowerCase().includes(item.genreMatch.toLowerCase()) ||
                        t.query?.toLowerCase().includes(item.genreMatch.toLowerCase())
                    ).length;
                    if (matchCount > 0) {
                        console.log(`  🔥 [Market Hit] ${item.genreMatch}: +${matchCount * 25}점`);
                        item.score += matchCount * 25;
                    }
                    return item;
                });
            }

        } else {
            // ✨ 성공 강화 (70%)
            mode = 'Exploitation';
            console.log('\n✨ [Exploitation] 70% — 채널 성공 데이터 기반 강화');
            const successfulGenres = lessons_learned.successful_genres || [];
            if (successfulGenres.length > 0) {
                weightTable = weightTable.map(item => {
                    const hit = successfulGenres.some(sg =>
                        sg.toLowerCase().includes(item.genreMatch.toLowerCase())
                    );
                    if (hit) {
                        console.log(`  ✅ [Reward] ${item.genreMatch}: +50점`);
                        item.score += 50;
                    }
                    return item;
                });
            }
        }

        // ④ 기술적 결함 패널티
        const issues = lessons_learned.technical_issues || [];
        if (issues.length > 0) {
            const badStr = issues.join(' ').toLowerCase();
            weightTable.forEach(item => {
                if (badStr.includes(item.genreMatch.toLowerCase())) {
                    console.log(`  ⚠️  [Penalty] ${item.genreMatch}: -30점 (기술 결함)`);
                    item.score -= 30;
                }
            });
        }

        // ⑤ 성과 히스토리 기반 보정
        const history = lessons_learned.performance_history || [];
        if (history.length > 0) {
            weightTable = weightTable.map(item => {
                const totalViews = history
                    .filter(h => h.theme === item.theme)
                    .reduce((sum, h) => sum + (h.viewCount || 0), 0);
                const bonus = Math.floor(totalViews / 200);
                if (bonus > 0) {
                    console.log(`  📈 [History Bonus] ${item.theme}: +${bonus}점 (누적 조회수 기반)`);
                    item.score += bonus;
                }
                return item;
            });
        }

        // ⑥ 최종 정렬 및 선택
        const sorted  = weightTable.sort((a, b) => b.score - a.score);
        const optimal = sorted[Math.min(rank, sorted.length - 1)];

        console.log(`\n✅ [Final Decision] Mode: ${mode}`);
        console.log(`   → Theme : ${optimal.theme}`);
        console.log(`   → Score : ${optimal.score.toFixed(1)}`);
        console.log('─'.repeat(46));

        return optimal.theme;
    }

    // ── 구조화된 프롬프트 생성 ─────────────────
    generateStructuredPrompt(index = 0, isInstrumental = false, overrideTheme = null) {
        let theme = overrideTheme || this.trends.themes[index % this.trends.themes.length];
        let genre, mood, instrument, vocal;
        const originalThemeName = theme;

        // 테마별 세부 설정
        if (theme === 'OZ CAFE') {
            const styles = [
                { genre: 'Slow Jazz Ballad',  mood: 'Smoky & Nostalgic',       instrument: 'Muted Trumpet, soft Piano, double Bass, brush Drums' },
                { genre: 'Fast Bebop Jazz',   mood: 'Energetic & Intellectual', instrument: 'Virtuosic Bebop Piano, Trumpet flares, Saxophone, walking Bass' },
                { genre: 'Cool Jazz',          mood: 'Relaxed & Sophisticated', instrument: 'Vibraphone, soft Saxophone, Piano, brushed Drums' },
                { genre: 'Bossa Nova Jazz',    mood: 'Breezy & Romantic',       instrument: 'Nylon Guitar, Flute, light Percussion, Upright Bass' },
                { genre: 'Smooth Soul Jazz',   mood: 'Warm & Groovy',           instrument: 'Rhodes Piano, Electric Guitar, Jazz Drum loop' },
                { genre: 'Hard Bop',           mood: 'Dynamic & Soulful',       instrument: 'Hard-hitting Drums, aggressive Saxophone, Driving Bass' },
                { genre: 'Gypsy Jazz',         mood: 'Vibrant & Acoustic',      instrument: 'Acoustic Gypsy Guitar, Violin, double Bass' },
                { genre: 'Modal Jazz',         mood: 'Atmospheric & Meditative', instrument: 'Sustained Piano chords, improvisational Saxophone' },
                { genre: 'Swing Jazz',         mood: 'Classic & Upbeat',        instrument: 'Big Band horns, rhythmic Piano, swinging Drums' },
                { genre: 'Latin Jazz',         mood: 'Rhythmic & Spicy',        instrument: 'Congas, Piano montunos, Trumpet, intense Bass' }
            ];
            const style = styles[index % styles.length];
            genre      = `1960s ${style.genre}`;
            mood       = style.mood;
            instrument = style.instrument;
            theme      = `1960s ${style.genre} style`;

        } else if (theme === 'Lofi Study Room') {
            genre      = 'Lo-Fi Hip Hop / Chillhop';
            mood       = 'Dusty, Warm, Focus-friendly';
            instrument = 'Sampled Piano, Lo-Fi Drums, Vinyl crackle, Soft Bass';
            isInstrumental = true;

        } else if (theme === 'Nature/ASMR Sanctuary') {
            genre      = 'Organic Healing Ambient';
            mood       = 'Deep Relaxing & Meditative';
            instrument = 'Soft Piano & Nature Soundscapes (rain, wind, water)';
            isInstrumental = true;

        } else if (theme === 'Classical Performance') {
            genre      = 'Classical Grand Orchestra';
            mood       = 'Majestic & Emotional';
            instrument = 'Symphony Orchestra, Grand Piano, Cinematic Strings, Woodwinds';
            isInstrumental = true;

        } else if (theme === 'Tokyo City Pop') {
            genre      = 'Japanese City Pop / Funk';
            mood       = 'Groovy, Nostalgic, Summery';
            instrument = 'Fender Rhodes, Slap Bass, Disco Strings, Saxophone, Chorus Guitar';
            vocal      = 'Smooth Japanese-style Vocal or Instrumental';

        } else if (theme === 'Euro Synth Night') {
            genre      = 'Modern Euro Synthwave';
            mood       = 'Driving & Energetic';
            instrument = 'Vintage Analogue Synths, Punchy Drum Machine, Arpeggiated Bass';

        } else if (theme === 'Spring Blossom Walk') {
            genre      = 'Spring Mid-tempo Acoustic Pop / Folk';
            mood       = 'Warm, Romantic, Joyful, Breezy';
            instrument = 'Warm Acoustic Guitar, Grand Piano, Harmonica solos, soft Percussion';
            vocal      = 'Deep, Warm, Sweet Male Vocal';

        } else if (theme === 'Midnight Chill') {
            genre      = 'Downtempo / Chillout Electronic';
            mood       = 'Deep, Hazy, Late-night';
            instrument = 'Deep Sub Bass, Atmospheric Pads, Broken Beat Drums, Electric Piano';
            isInstrumental = true;

        } else if (theme === 'Seoul Rainy Day') {
            genre      = 'Korean Indie / Acoustic Folk';
            mood       = 'Emotional, Rainy, Nostalgic';
            instrument = 'Acoustic Guitar, Soft Piano, light Drum brushes, occasional Strings';
            vocal      = 'Warm Korean Male or Female Vocal';

        } else if (theme === 'Cinematic Orchestral') {
            genre      = 'Epic Cinematic Orchestra';
            mood       = 'Majestic, Sweeping, Emotional';
            instrument = 'Full Orchestral Strings, Brass, Choir, Timpani, Grand Piano';
            isInstrumental = true;

        } else if (theme === 'Neo Soul Groove') {
            genre      = 'Neo Soul / Contemporary R&B';
            mood       = 'Soulful, Smooth, Sensual';
            instrument = 'Rhodes Piano, Warm Bass Guitar, Live Drums, Lush Strings';

        } else if (theme === 'Deep Sleep Therapy') {
            genre      = 'Sleep / Delta Wave Ambient';
            mood       = 'Ultra-calm, Drifting, Weightless';
            instrument = 'Gentle Drones, Soft Pads, Binaural textures, Wind chimes';
            isInstrumental = true;

        } else if (theme === 'Midnight Solstice Afro') {
            genre      = 'Afro House / Tribal Electronic';
            mood       = 'Hypnotic, Ritualistic, Deep';
            instrument = 'Tribal Percussion, Hypnotic Synths, Deep Bass, African Chants';

        } else if (theme === 'Aura Brazilian Bounce') {
            genre      = 'Brazilian Phonk / Funk';
            mood       = 'Viral, Aggressive, High Energy';
            instrument = 'Distorted 808 Bass, Aggressive Trap Drums, Whistle synth';

        } else if (theme === 'Cozy Acoustic Evening') {
            genre      = 'Acoustic Folk / Singer-Songwriter';
            mood       = 'Intimate, Warm, Introspective';
            instrument = 'Fingerpicked Acoustic Guitar, soft Cello, gentle Brush Drums';

        } else if (theme === 'Funk Groove Session') {
            genre      = 'Jazz Funk / Electric Fusion';
            mood       = 'Energetic, Soulful, Rhythmic';
            instrument = 'Fender Bass, Clavinet, Brass Section, Funky Drums';

        } else if (theme === 'Berlin Minimal') {
            genre      = 'Minimal Techno / Dark Ambient';
            mood       = 'Cold, Hypnotic, Industrial';
            instrument = 'Modular Synths, Cold Drum Machine, Sub Bass Drone';
            isInstrumental = true;

        } else if (theme === 'Winter Christmas Jazz') {
            genre      = 'Christmas Jazz Lounge';
            mood       = 'Warm, Festive, Cozy';
            instrument = 'Upright Bass, Brushed Drums, Muted Trumpet, Warm Piano';

        } else if (theme === 'Autumn Nostalgic Walk') {
            genre      = 'Acoustic Indie Folk';
            mood       = 'Melancholic, Warm, Nostalgic';
            instrument = 'Acoustic Guitar, Cello, Soft Piano, light Brush Percussion';
            vocal      = 'Warm Male Vocal with emotional depth';

        } else {
            genre      = this.trends.genres[index % this.trends.genres.length];
            mood       = this.trends.moods[index % this.trends.moods.length];
            instrument = this.trends.instruments[index % this.trends.instruments.length];
        }

        vocal = vocal || (isInstrumental
            ? 'Instrumental Only'
            : this.trends.vocals[index % (this.trends.vocals.length - 1)]);

        // 음악 이론 정보
        const theory = this.musicTheory[originalThemeName] || {};

        // 레퍼런스 아티스트 (내부 전용)
        const artists = this.referenceArtists[originalThemeName]?.internal || [];
        const artistRef = artists.length > 0 ? `Inspired by the era of ${artists[0]}` : '';

        // 곡 구조
        const structure = isInstrumental ? this.songStructure.ambient : this.songStructure.longMix;

        // 최종 Lyria 3 프롬프트
        const fullPrompt = [
            `As the world's best and most versatile music composer, create a masterpiece using Lyria 3:`,
            `Genre: ${genre}.`,
            `Mood: ${mood}.`,
            `Instruments: ${instrument}.`,
            `Vocal: ${vocal}.`,
            theory.bpm ? `BPM: ${theory.bpm}, Key: ${theory.key}, Feel: ${theory.feel}.` : '',
            `Structure: ${structure}.`,
            artistRef ? `${artistRef}.` : '',
            `Theme: ${theme}.`,
            `High fidelity, professional studio quality.`
        ].filter(Boolean).join(' ');

        const lyrics           = isInstrumental ? null : (this.lyricTemplates[originalThemeName] || 'Instrumental.');
        const storytellingTitle = isInstrumental
            ? `[Instrumental] ${this.generateStorytellingTitle({ genre, mood, theme: originalThemeName, index })}`
            : this.generateStorytellingTitle({ genre, mood, theme: originalThemeName, index });
        const shortsHook       = this.generateShortsHook(originalThemeName, index);
        const seoTags          = this.generateSEOTags(originalThemeName, genre, mood);
        const thumbnailPrompt  = this.generateThumbnailPrompt(originalThemeName);
        const engagementQ      = this.generateEngagementQuestion();

        return {
            fullPrompt,
            lyrics,
            storytellingTitle,
            shortsHook,
            seoTags,
            thumbnailPrompt,
            engagementQuestion: engagementQ,
            components: { genre, mood, instrument, vocal, theme: originalThemeName, isInstrumental }
        };
    }

    // ── 스토리텔링 타이틀 ─────────────────────
    generateStorytellingTitle({ genre, mood, theme, index = 0 }) {
        const subTitles = this.trackSubTitles[theme] || [];
        const uniqueSub = subTitles.length > 0 ? subTitles[index % subTitles.length] : `${genre} Mood`;

        const scenarios = {
            "OZ CAFE":                `[OZ] | Cafe & Study | - Cozy ${uniqueSub} 🎧`,
            "Lofi Study Room":        `[OZ] | Lofi Study | - ${uniqueSub} 📚`,
            "Nature/ASMR Sanctuary":  `[OZ] | Healing ASMR | - ${uniqueSub} 🌿`,
            "Classical Performance":  `[OZ] | Classical | - ${uniqueSub} 🎹`,
            "Tokyo City Pop":         `[OZ] | City Pop | - ${uniqueSub} 🌆`,
            "Euro Synth Night":       `[OZ] | Night Drive | - ${uniqueSub} 🏎️`,
            "Spring Blossom Walk":    `[OZ] | Spring | - ${uniqueSub} 🌸`,
            "Midnight Chill":         `[OZ] | Midnight | - ${uniqueSub} 🌙`,
            "Seoul Rainy Day":        `[OZ] | 감성 | - ${uniqueSub} 🌧️`,
            "Cinematic Orchestral":   `[OZ] | Cinematic | - ${uniqueSub} 🎻`,
            "Midnight Solstice Afro": `[OZ] | Solstice | - ${uniqueSub} 🌙`,
            "Aura Brazilian Bounce":  `[OZ] | Aura | - ${uniqueSub} ⚡`,
            "Deep Sleep Therapy":     `[OZ] | Sleep | - ${uniqueSub} 😴`,
            "Autumn Nostalgic Walk":  `[OZ] | Autumn | - ${uniqueSub} 🍂`
        };

        return scenarios[theme] || `[OZ] ${theme} - ${uniqueSub}`;
    }

    // ── 바이럴 타이틀 ─────────────────────────
    generateViralTitle(components) {
        const { genre, mood, theme, isInstrumental } = components;
        const template = this.viralTitleTemplates[Math.floor(Math.random() * this.viralTitleTemplates.length)];

        const map = {
            '{Genre}':     genre.replace(/1960s /g, ''),
            '{Theme}':     theme.replace(/ style/g, ''),
            '{Mood}':      mood,
            '{Situation}': theme.includes('CAFE') ? 'Deep Study' : (theme.includes('Classical') ? 'Deep Focus' : 'Relaxation'),
            '{Benefit}':   theme.includes('CAFE') ? 'Boost Focus' : (theme.includes('Nature') ? 'Heal Your Soul' : 'Relieve Stress'),
            '{Target}':    'Work & Study'
        };

        let title = template;
        for (const [key, val] of Object.entries(map)) {
            title = title.replace(key, val);
        }

        if (isInstrumental && !title.includes('Instrumental')) {
            title += ' [Instrumental]';
        }

        return title.substring(0, 100);
    }

    // ── Shorts 훅 ─────────────────────────────
    generateShortsHook(theme, index) {
        const hooks = this.shortsHooks[theme] || ['Experience the evolution of sound with OZ 🎧'];
        return hooks[index % hooks.length];
    }

    // ── SEO 태그 ──────────────────────────────
    generateSEOTags(theme, genre, mood) {
        const baseTags   = ['AI Music', 'Oz AI Artist', 'Soundscape', `${new Date().getFullYear()} Music`];
        const intentTags = [
            `${genre} for study`,
            `${theme} atmosphere`,
            `Relaxing ${genre} music`,
            `${mood} vibes for work`,
            `Focus music ${new Date().getFullYear()}`,
            'No Copyright AI Music',
            'Background Music',
            'Study Music'
        ];
        return [...baseTags, ...intentTags];
    }

    // ── 썸네일 프롬프트 ───────────────────────
    generateThumbnailPrompt(theme) {
        const concept = this.thumbnailConcepts[theme];
        if (!concept) return null;
        return [
            `Cinematic YouTube thumbnail:`,
            `${concept.style}.`,
            `Bold text overlay: "${concept.text}".`,
            `Color palette: ${concept.colorPalette.join(', ')}.`,
            `16:9 ratio, 1280x720px, ultra high quality.`
        ].join(' ');
    }

    // ── 참여 유도 질문 ────────────────────────
    generateEngagementQuestion() {
        const questions = [
            '💬 Question of the Day: What mood are you in right now?',
            '🌍 Where are you listening from today? Drop your city below!',
            '☕ What\'s your favorite drink while listening to this mix?',
            '✨ If this music was a place, where would it be?',
            '🎧 How did you find this channel? Algorithm or a friend?',
            '🌙 What are you working on while this plays in the background?',
            '🎵 Which part of this mix is your favorite so far?',
            '📚 Tell me what you\'re studying today — I\'m curious!',
            '🌿 What does this music make you feel? Drop a word below.',
            '🔁 Do you loop music when you work? Or do you need silence?'
        ];
        return questions[Math.floor(Math.random() * questions.length)];
    }
}

module.exports = new PromptEngineer();
